<?php

$host = "localhost";
$port = "5432";
$dbname = "it_prof";
$user = "postgres";
$password = "admin";

// Create connection string
$connection = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$connection) {
    // Connection failed
    echo "Connection failed: " . pg_last_error();
}

?>
