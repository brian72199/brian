<?php

$secret_key = array(
    'secret_key' => 'sekretongmalupitlebronjames'
);

return $secret_key;

?>
