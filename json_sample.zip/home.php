<? include './header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col">qweqw</div>
    </div>
</div>



<? include './footer.php'; ?>